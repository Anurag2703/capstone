import pandas as pd

# Load your Bhagavad Gita dataset
df = pd.read_excel("Bhagwad_Gita.xlsx")

# Initialize Sentiment column
df["Sentiment"] = ""

# Define your mapping manually
sentiment_map = {
    "anger": [
        (2, 56), (2, 62), (2, 63), (5, 26),
        (16, 1), (16, 2), (16, 3), (16, 21)
    ],
    "confusion": [(2, 7), (3, 2), (18, 61)],
    "dealing with envy": [(12, 13), (12, 14), (16, 19), (18, 71)],
    "death of a loved one": [(2, 13), (2, 20), (2, 22), (2, 25), (2, 27)],
    "demotivated": [(11, 33), (18, 48), (18, 78)],
    "discriminated": [(5, 18), (5, 19), (6, 32), (9, 29)],
    "fear": [(4, 10), (11, 50), (18, 30)],
    "feeling sinful": [(4, 36), (4, 37), (5, 10), (9, 30), (10, 3), (14, 6), (18, 66)],
    "forgetfulness": [(15, 15), (18, 61)],
    "depression": [(2, 3), (2, 14), (5, 21)],
    "greed": [(14, 17), (16, 21), (17, 25)],
    "laziness": [(3, 8), (3, 20), (6, 16), (18, 39)],
    "loneliness": [(6, 30), (9, 29), (13, 16), (13, 18)],
    "losing hope": [(4, 11), (9, 22), (9, 34), (18, 66), (18, 78)],
    "lust": [(3, 37), (3, 41), (3, 43), (5, 22), (16, 21)],
    "practicing forgiveness": [(11, 44), (12, 13), (12, 14), (16, 1), (16, 2), (16, 3)],
    "pride": [(16, 4), (16, 13), (16, 14), (16, 15), (18, 26), (18, 58)],
    "seeking peace": [(2, 66), (2, 71), (4, 39), (5, 29), (8, 28)],
    "temptation": [(2, 60), (2, 61), (2, 70), (7, 14)],
    "uncontrolled mind": [(6, 5), (6, 6), (6, 26), (6, 35)]
}

# Normalize function
def normalize_sentiment(s):
    return s.strip().lower()

# Apply mapping
for sentiment, pairs in sentiment_map.items():
    for chapter, verse in pairs:
        mask = (df["Chapter"] == chapter) & (df["Verse"] == verse)
        df.loc[mask, "Sentiment"] = normalize_sentiment(sentiment)

# Preview updated rows with sentiment
df_with_sentiment = df[df["Sentiment"] != ""]
print(f"Annotated {len(df_with_sentiment)} verses with sentiment tags.")

# Save the updated dataset
df.to_excel("Bhagwad_Gita_with_Sentiment.xlsx", index=False)